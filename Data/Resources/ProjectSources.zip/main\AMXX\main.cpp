#include <amxx/api.h>

AmxxStatus on_amxx_attach()
{
	return AmxxStatus::Ok;
}

void on_amxx_detach()
{
}
