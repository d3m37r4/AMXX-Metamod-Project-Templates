#include <metamod/api.h>

MetamodStatus on_meta_attach()
{
	return MetamodStatus::Ok;
}

void on_meta_detach()
{
}
